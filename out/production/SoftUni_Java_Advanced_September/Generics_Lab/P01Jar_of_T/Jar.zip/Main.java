
public class Main {
    public static void main(String[] args) {

        Jar<String> stringJar = new Jar<>();

        stringJar.add("Ivan");
        stringJar.add("Pres");

        Jar<Integer> num = new Jar<>();

        num.add(3);

    }
}
